package classicMod.library.ai;

import arc.math.geom.Geometry;
import arc.math.geom.Point2;
import arc.struct.Seq;
import arc.util.Nullable;
import arc.util.Time;
import classicMod.content.RVars;
import classicMod.library.blocks.neoplasiaBlocks.CausticHeart;
import mindustry.Vars;
import mindustry.content.Blocks;
import mindustry.entities.units.AIController;
import mindustry.world.Tile;

public class NeoplasmAIController extends AIController {
    public boolean update;
    /** Suppress heat-map recording only for intentional self-removal (for example, cord placement). */
    public boolean ignoreDeathHeat;
    /** Existing combat/AI state flag; not related to death heat recording. */
    public boolean ignore;

    /** Every Neoplasm controller records its own route history automatically. */
    @Override
    public void updateUnit() {
        updateNeoplasmTracking();
        super.updateUnit();
    }

    // Short per-unit history prevents repeatedly reversing between the same tiles.
    private final int[] recentTiles = new int[24];
    private int recentTileCursor;
    private int recentTileCount;
    private int lastRecordedTile = -1;

    // Local danger checks are identical for several consecutive movement ticks.
    private int avoidOrigin = -1, avoidDestination = -1, avoidTarget = -1;
    private float avoidUntil = -1f;
    private boolean avoidResult;

    private int strategicOrigin = -1, strategicDestination = -1, strategicTarget = -1;
    private float strategicUntil = -1f;
    private boolean strategicResult;

    // Stagger expensive danger/path checks by distance while allowing all layers
    // within the same scheduled decision tick to cooperate.
    private int riskInterval = 5;
    private int activeDecisionTick = Integer.MIN_VALUE;
    private float nextRiskIntervalRefresh = -1f;

    private boolean shouldUpdateRisk() {
        if (unit == null) return false;
        int tick = (int)Time.time;
        if (activeDecisionTick == tick) return true;

        if (Time.time >= nextRiskIntervalRefresh) {
            var core = unit.closestEnemyCore();
            if (core == null) {
                riskInterval = 5;
            } else {
                float dx = unit.x - core.x, dy = unit.y - core.y;
                float distance2 = dx * dx + dy * dy;
                riskInterval = distance2 > 2560f * 2560f ? 10
                        : distance2 > 1024f * 1024f ? 5 : 2;
            }
            nextRiskIntervalRefresh = Time.time + 60f;
        }
        if (Math.floorMod(tick + unit.id, riskInterval) != 0) return false;
        activeDecisionTick = tick;
        NeoplasmPerfMonitor.riskDecision();
        return true;
    }

    /** Initialize the shared death listener and record this unit's recent route. */
    public void updateNeoplasmTracking() {
        NeoplasmDeathHeatmap.init();
        if (unit == null) return;

        Tile current = unit.tileOn();
        if (current == null) return;
        int index = current.array();
        if (index == lastRecordedTile) return;

        recentTiles[recentTileCursor] = index;
        recentTileCursor = (recentTileCursor + 1) % recentTiles.length;
        recentTileCount = Math.min(recentTileCount + 1, recentTiles.length);
        lastRecordedTile = index;
    }

    /** Mild penalty for revisiting a recently crossed tile; prevents 2-tile ping-pong without blocking retreats. */
    private float revisitPenalty(Tile tile) {
        if (tile == null) return 0f;
        int index = tile.array();
        for (int age = 0; age < recentTileCount; age++) {
            int position = (recentTileCursor - 1 - age + recentTiles.length) % recentTiles.length;
            if (recentTiles[position] == index) {
                return Math.max(0f, 9f - age * 0.35f);
            }
        }
        return 0f;
    }

    @Nullable
    public Tile getClosestVent() {
        Tile closest = null;
        float bestDst2 = Float.MAX_VALUE;
        for (Tile tile : PathfinderExtended.SteamVents) {
            if (tile == null || tile.build instanceof CausticHeart.HeartBuilding) continue;
            float dst2 = unit.dst2(tile.worldx(), tile.worldy());
            if (dst2 < bestDst2) {
                bestDst2 = dst2;
                closest = tile;
            }
        }
        return closest;
    }

    @Nullable
    public Tile getClosestVent(boolean avoidDangerous) {
        if (!avoidDangerous) return getClosestVent();

        Tile closest = null;
        float bestScore = Float.MAX_VALUE;
        for (Tile tile : PathfinderExtended.SteamVents) {
            if (tile == null || tile.build instanceof CausticHeart.HeartBuilding) continue;
            float score = unit.dst(tile.worldx(), tile.worldy())
                    + dangerDistance(tile) * NeoplasmDeathHeatmap.directHeatWeight;
            if (score < bestScore) {
                bestScore = score;
                closest = tile;
            }
        }
        return closest;
    }

    @Nullable
    public Tile getClosestTarget(int range) {
        int r = (range % 2 == 1) ? range + 1 : range;
        int mid = r / 2;
        Seq<Tile> available = new Seq<>();
        for (int y = -mid; y <= mid; y++) {
            for (int x = -mid; x <= mid; x++) {
                Tile tile = Vars.world.tile(unit.tileX() + x, unit.tileY() + y);
                if (tile != null && tile.block() == Blocks.air
                        && tile.floor() != null && !tile.floor().isLiquid) {
                    available.add(tile);
                }
            }
        }
        if (available.isEmpty()) return null;
        if (target != null) {
            available.sort(tile -> tile.dst2(target));
        } else {
            available.sort(tile -> tile.dst2(unit));
        }
        return available.first();
    }

    /** Returns the shared heat at a tile (higher means more dangerous). */
    public float dangerDistance(Tile tile) {
        return tile == null ? 0f : NeoplasmDeathHeatmap.getHeat(unit.team, tile);
    }

    /**
     * Choose a nearby flowfield step using destination cost + shared heat +
     * recent-visit penalty.
     */
    @Nullable
    public Tile getDodgeTarget(int pathTarget, Tile tile) {
        NeoplasmPerfMonitor.pathRequest();
        long perfStart = NeoplasmPerfMonitor.startTimer();
        try {
            return getDodgeTargetInternal(pathTarget, tile);
        } finally {
            NeoplasmPerfMonitor.endTimer(NeoplasmPerfMonitor.TIMER_PATH, perfStart);
        }
    }

    @Nullable
    private Tile getDodgeTargetInternal(int pathTarget, Tile tile) {
        if (tile == null || unit == null || RVars.pathfinderCustom == null || !shouldUpdateRisk()) return null;

        // Prefer a whole-route danger-aware path before applying the local fallback.
        Tile strategic = NeoplasmStrategicPathfinder.nextStep(
                tile, unit.team, unit.type.flowfieldPathType, pathTarget, unit.id
        );
        if (strategic != null && strategic != tile) return strategic;

        var field = RVars.pathfinderCustom.getField(unit.team, unit.type.flowfieldPathType, pathTarget);
        if (field == null || !field.initialized || !field.hasTargets()) return null;

        int[] weights = field.hasComplete ? field.completeWeights : field.weights;
        int current = tile.array();
        if (current < 0 || current >= weights.length || weights[current] < 0) return null;

        int currentWeight = weights[current];
        float currentHeat = dangerDistance(tile);
        Tile best = null;
        float bestScore = Float.MAX_VALUE;
        Tile normalNext = null;
        int normalWeight = Integer.MAX_VALUE;
        float normalScore = Float.MAX_VALUE;

        for (Point2 offset : Geometry.d8) {
            Tile candidate = Vars.world.tile(tile.x + offset.x, tile.y + offset.y);
            if (candidate == null) continue;

            int index = candidate.array();
            if (index < 0 || index >= weights.length || !field.passable(index)) continue;
            if (offset.x != 0 && offset.y != 0) {
                Tile horizontal = Vars.world.tile(tile.x + offset.x, tile.y);
                Tile vertical = Vars.world.tile(tile.x, tile.y + offset.y);
                if (horizontal == null || vertical == null
                        || !field.passable(horizontal.array()) || !field.passable(vertical.array())) continue;
            }

            int progress = weights[index];
            if (progress < 0) continue;

            // Allow a bounded temporary increase in path cost for a real detour.
            if (progress > currentWeight + 72 && currentHeat < 25f) continue;

            float heat = dangerDistance(candidate);
            float score = progress
                    + heat * NeoplasmDeathHeatmap.pathHeatWeight
                    + revisitPenalty(candidate);

            if (progress < normalWeight) {
                normalWeight = progress;
                normalNext = candidate;
                normalScore = score;
            }

            if (score < bestScore) {
                bestScore = score;
                best = candidate;
            }
        }

        if (best == null || normalNext == null) return null;

        float normalHeat = dangerDistance(normalNext);
        if (currentHeat < 2f && normalHeat < 2f) return null;

        float currentScore = currentWeight + currentHeat * NeoplasmDeathHeatmap.pathHeatWeight;
        float baseline = Math.min(normalScore, currentScore);
        if (bestScore + 0.5f < baseline) return best;

        if (currentHeat >= 25f && dangerDistance(best) < currentHeat
                && revisitPenalty(best) < 7f) return best;

        return null;
    }

    /** Soft local detour for direct-movement flying and Hug-style units. */
    protected boolean avoidNearbyDanger(Tile destination) {
        long perfStart = NeoplasmPerfMonitor.startTimer();
        try {
            return avoidNearbyDangerInternal(destination);
        } finally {
            NeoplasmPerfMonitor.endTimer(NeoplasmPerfMonitor.TIMER_STEERING, perfStart);
        }
    }

    private boolean avoidNearbyDangerInternal(Tile destination) {
        if (destination == null || unit == null) return false;
        Tile current = unit.tileOn();
        if (current == null) return false;

        int originIndex = current.array();
        int destinationIndex = destination.array();
        if (Time.time < avoidUntil && avoidOrigin == originIndex
                && avoidDestination == destinationIndex) {
            if (!avoidResult) return false;
            Tile cached = Vars.world.tile(avoidTarget);
            if (cached != null && cached != current && unit.canPass(cached.x, cached.y)) {
                unit.movePref(vec.set(cached.worldx(), cached.worldy()).sub(unit).limit(unit.speed()));
                return true;
            }
        }

        if (!shouldUpdateRisk()) return false;
        avoidOrigin = originIndex;
        avoidDestination = destinationIndex;
        avoidUntil = Time.time + 6f;
        avoidResult = false;
        avoidTarget = -1;

        Tile best = null;
        float bestScore = Float.MAX_VALUE;
        Tile normalNext = null;
        float normalScore = Float.MAX_VALUE;
        float normalDst = Float.MAX_VALUE;

        for (Point2 offset : Geometry.d8) {
            Tile candidate = Vars.world.tile(current.x + offset.x, current.y + offset.y);
            if (candidate == null || !unit.canPass(candidate.x, candidate.y)) continue;
            if (offset.x != 0 && offset.y != 0
                    && (!unit.canPass(current.x + offset.x, current.y)
                    || !unit.canPass(current.x, current.y + offset.y))) continue;

            float dst = candidate.dst(destination);
            float heat = dangerDistance(candidate);
            float score = dst
                    + heat * NeoplasmDeathHeatmap.directHeatWeight
                    + revisitPenalty(candidate);

            if (score < bestScore) {
                bestScore = score;
                best = candidate;
            }
            if (dst < normalDst) {
                normalDst = dst;
                normalNext = candidate;
                normalScore = score;
            }
        }

        if (best == null || normalNext == null) return false;
        float currentHeat = dangerDistance(current);
        float normalHeat = dangerDistance(normalNext);
        if (currentHeat < 2f && normalHeat < 2f) return false;

        float baseline = Math.min(normalScore,
                current.dst(destination) + currentHeat * NeoplasmDeathHeatmap.directHeatWeight);
        if (bestScore + 0.5f >= baseline && currentHeat < 25f) return false;

        if (best == normalNext && currentHeat < 25f) return false;
        if (currentHeat >= 25f && dangerDistance(best) >= currentHeat
                && revisitPenalty(best) >= 7f) return false;

        avoidResult = true;
        avoidTarget = best.array();
        unit.movePref(vec.set(best.worldx(), best.worldy()).sub(unit).limit(unit.speed()));
        return true;
    }

    public void routeAir() {
        if (target == null) return;
        Tile destination = target.tileOn();
        if (destination != null && avoidNearbyDanger(destination)) return;
        vec.set(target.getX() - unit.x, target.getY() - unit.y);
        if (!vec.isZero()) unit.movePref(vec.setLength(unit.speed()));
    }

    /**
     * Uses a danger-aware strategic route to approach a specific target
     * by the safest available path. Returns false when the normal movement AI
     * should retain control.
     */
    public boolean applyStrategicTarget(Tile destination, float stopDistance, int costType) {
        long perfStart = NeoplasmPerfMonitor.startTimer();
        try {
            return applyStrategicTargetInternal(destination, stopDistance, costType);
        } finally {
            NeoplasmPerfMonitor.endTimer(NeoplasmPerfMonitor.TIMER_STEERING, perfStart);
        }
    }

    private boolean applyStrategicTargetInternal(Tile destination, float stopDistance, int costType) {
        if (unit == null || destination == null || RVars.pathfinderCustom == null) return false;
        if (unit.within(destination.worldx(), destination.worldy(), stopDistance)) return false;

        Tile current = unit.tileOn();
        if (current == null) return false;

        int originIndex = current.array();
        int destinationIndex = destination.array();
        if (Time.time < strategicUntil && strategicOrigin == originIndex
                && strategicDestination == destinationIndex) {
            if (!strategicResult) return false;
            Tile cached = Vars.world.tile(strategicTarget);
            if (cached != null && cached != current && unit.canPass(cached.x, cached.y)) {
                unit.movePref(vec.trns(unit.angleTo(cached.worldx(), cached.worldy()), unit.speed()));
                return true;
            }
        }

        if (!shouldUpdateRisk()) return false;
        strategicOrigin = originIndex;
        strategicDestination = destinationIndex;
        strategicUntil = Time.time + 6f;
        strategicResult = false;
        strategicTarget = -1;

        Tile next = NeoplasmStrategicPathfinder.nextStepTo(
                current, destination, unit.team, costType, unit.id
        );
        if (next == null || next == current || !unit.canPass(next.x, next.y)) return false;

        strategicResult = true;
        strategicTarget = next.array();
        unit.movePref(vec.trns(unit.angleTo(next.worldx(), next.worldy()), unit.speed()));
        return true;
    }

    public boolean applyDodgePathfind(int pathTarget) {
        if (unit == null) return false;
        Tile tile = unit.tileOn();
        if (tile == null) return false;

        Tile next = getDodgeTarget(pathTarget, tile);
        if (next == null || next == tile || !unit.canPass(next.x, next.y)) return false;

        unit.movePref(vec.trns(unit.angleTo(next.worldx(), next.worldy()), unit.speed()));
        return true;
    }

    @Override
    public void pathfind(int pathTarget) {
        int costType = unit.type.flowfieldPathType;
        Tile tile = unit.tileOn();
        if (tile == null) return;

        Tile next = getDodgeTarget(pathTarget, tile);
        if (next != null && next != tile && unit.canPass(next.x, next.y)) {
            unit.movePref(vec.trns(unit.angleTo(next.worldx(), next.worldy()), unit.speed()));
            return;
        }

        Tile targetTile = Vars.pathfinder.getTargetTile(tile,
                Vars.pathfinder.getField(unit.team, costType, pathTarget));
        if (targetTile != null && targetTile != tile && unit.canPass(targetTile.x, targetTile.y)) {
            unit.movePref(vec.trns(unit.angleTo(targetTile.worldx(), targetTile.worldy()), unit.speed()));
        }
    }
}
